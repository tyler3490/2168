package recursionAssignments;
import java.util.*;
public class eightQueens {



	public static void main(String[] args) {
		int[][] board = new int[8][8]; 
		printBoard(board);
		solve(board, 0);
		System.out.println();
		printBoard(board);
	}
	
	public static void printBoard(int[][] board) {
		for(int[] row : board)
			System.out.println(Arrays.toString(row));
	}
	
	public static boolean solve(int[][] board, int pos){
//		if we have checked every column and placed a queen there they should all be in a valid position so we can stop
		if(pos >= 8){
			return true;
		}
//		this starts at col 0 and goes down the col, row by row to check for a valid position 
		for(int i = 0; i < 8; i++){
			if(valid(board, i, pos)){
				board[i][pos] = 1;
//				then increment pos (the col) call again on the next row, again it will check all the columns in that row for a valid position
				if(solve(board, pos + 1) == true){
					return true;
				}
			}
//		else valid has failed and this is not a possible position so we set it back to 0 and go to the last queen and try to place it in a new spot
			board[i][pos] = 0;
		}
		return false; // backtrack
	}
	
	public static boolean valid(int[][] board, int row, int col) {
//		we only need to check the areas that we have already placed a queen in, i.e. only to the left
//		check your current row for any queen in it 
		for(int i = 0; i < col; i++) {
			if(board[row][i] == 1) {
				return false;
			}
		}
//		col goes down row goes down to check left and up diagonal 
		for (int i=row, j=col; i >= 0 && j >= 0; i--, j--) {
			if(board[i][j] == 1) {
				return false;
			}
		}
//		col goes down row goes up to check left and down diagonal 
		for (int i=row, j=col; i < 8 && j>=0; i++, j--) {
			if(board[i][j] == 1) {
				return false;
			}
		}
		return true;	
	}

}
