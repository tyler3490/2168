package sortingAlgorithms;

import java.io.*;
import java.util.*;

public class sortingWithInts {
// ints for keeping track of comparisons and exchanges 
	public static int exchanges = 0;
	public static int comps = 0;
	public static int avgExchanges = 0;
	public static int avgComps = 0;
	public static long avgTime = 0; 
	
	
//  insertion sort
    public static void insertionsort(int arr[]) {
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;
            
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
                exchanges++;
                comps++;
            }
            
            arr[j + 1] = key;
        }
    }

//  quicksort
    public static int partition(int arr[], int low, int high){
            int pivot = arr[high];
            int i = (low-1); 
            
            for (int j=low; j<high; j++){
                if (arr[j] < pivot){
                	comps++;
                    i++;
                    // swap arr[i] and arr[j]
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    exchanges++;
                }
            }
            
            // swap arr[i+1] and arr[high] (or pivot)
            int temp = arr[i+1];
            arr[i+1] = arr[high];
            arr[high] = temp;
            exchanges++;
            return i+1;
    }

    /* The main function that implements QuickSort()
      arr[] --> Array to be sorted,
      low  --> Starting index,
      high  --> Ending index */
     public static void quicksort(int arr[], int low, int high) {
    	 if (low < high){
    		comps++;           
            int pi = partition(arr, low, high);
            quicksort(arr, low, pi-1);
            quicksort(arr, pi+1, high);
         }
     }


//  mergesort
    // Merges two subarrays of arr[].
    // First subarray is arr[l..m]
    // Second subarray is arr[m+1..r]
    public static void mergeArr(int arr[], int l, int m, int r){
        // Find sizes of two subarrays to be merged
        int n1 = m - l + 1;
        int n2 = r - m;

        /* Create temp arrays */
        int L[] = new int [n1];
        int R[] = new int [n2];

        /*Copy data to temp arrays*/
        for (int i=0; i<n1; ++i) {
        	L[i] = arr[l + i];
//        	exchanges++;        	
        }
        for (int j=0; j<n2; ++j) {
        	R[j] = arr[m + 1+ j];
//        	exchanges++;
        }
        	


        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarry array
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                comps++;
                exchanges++;
                arr[k] = L[i];
                i++;
            }
            else {
                comps++;
                exchanges++;
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
//        	exchanges++;
            arr[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
//        	exchanges++;
            arr[k] = R[j];
            j++;
            k++;
        }
    }
        // Main function that sorts arr[l..r] using
        // merge()
    public static void mergesort(int arr[], int l, int r){
    	if (l < r){
            comps++;

            int m = (l+r)/2;

            // Sort first and second halves
            mergesort(arr, l, m);
            mergesort(arr , m+1, r);

            // Merge the sorted halves
            mergeArr(arr, l, m, r);
        }
    }

// file writer    
    public static void fileWriter(int comparisons, int exchanges, long runTime, String name, int run) throws IOException{    
    	FileWriter csv = new FileWriter("C:\\Users/Tyler/Desktop/sortingFiles/" + name + ".csv", true);
        csv.append(name + " run number: " + run );
        csv.append("\n");
        csv.append("Comparisons");
        csv.append(",");
        csv.append(String.valueOf(comparisons));
        csv.append("\n");
        csv.append("exchanges");
        csv.append(",");
        csv.append(String.valueOf(exchanges));
        csv.append("\n");
        csv.append("Run time");
        csv.append(",");
        csv.append(String.valueOf(runTime));
        csv.append("\n");
        csv.flush();
        csv.close();  
    }
    public static void writeAverages(int avgComps, int avgExchanges, long avgTime, String name) throws IOException{    
    	FileWriter csv = new FileWriter("C:\\Users/Tyler/Desktop/sortingFiles/" + name + ".csv", true);
        csv.append("\n");
        csv.append("Average number of comparisons");
        csv.append(",");
        csv.append(String.valueOf(avgComps));
        csv.append("\n");
        csv.append("Average number of exchanges");
        csv.append(",");
        csv.append(String.valueOf(avgExchanges));
        csv.append("\n");
        csv.append("Average run time");
        csv.append(",");
        csv.append(String.valueOf(avgTime));
        csv.append("\n");
        csv.flush();
        csv.close();  
    }

    public static void main(String args[]) throws IOException{
    	int runs = 100;
    	int sizeOfArray = 1000;
    	int randBound = 1000000;
    	String typeOfSort = "mergesort";
		String fileName = "performance of " + typeOfSort +" with " + runs + " runs -- array of size " + sizeOfArray + " and random ints from 0 to " + randBound;
    	for (int i = 0; i < runs; i++) {
    		comps = 0;
    		exchanges = 0;
        	Random rand = new Random();
			int[] inputArr = new int[sizeOfArray];
            
            for (int j = 0; j < inputArr.length-1; j++) {
                int r = rand.nextInt(randBound);
            	inputArr[j] = r;
//                inputArr.add((int) Math.pow(2, i));
            }
            
            long startTime = System.nanoTime();
//            insertionsort(inputArr);
//            quicksort(inputArr, 0, inputArr.length-1);
            mergesort(inputArr, 0, inputArr.length-1);
            long endTime = System.nanoTime() - startTime;
             
            System.out.println();
            fileWriter(comps, exchanges, endTime, fileName, i+1);
            
            avgComps += comps;
            avgExchanges += exchanges;
            avgTime += endTime;
    	}
    	writeAverages(avgComps/runs, avgExchanges/runs, avgTime/runs, fileName);
    	System.out.println(avgComps/runs);
    	System.out.println(avgExchanges/runs);
    	System.out.println(avgTime/runs);
    }
}
