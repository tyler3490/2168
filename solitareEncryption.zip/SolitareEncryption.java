package solitareEncryption;

import java.util.*;

public class SolitareEncryption {

	public static void main(String[] args) {
       String message = "Dr. McCaan is insane!";
       message = message.replaceAll("\\s", "").replaceAll("\\p{Punct}", "").toUpperCase().strip();
      
       while(!(message.length() % 5 == 0)) {
    	   message += "X";
       }

       int[] keyValueArray = getKeystream(message.length());
       
       String encryptedMessage = "";
       for (int i = 0; i < keyValueArray.length; i++) {
    	   encryptedMessage += encryptChar(message.charAt(i), keyValueArray[i]);
       }
       
       String decryptedMessage = "";
       for (int i = 0; i < keyValueArray.length; i++) {
    	   decryptedMessage += decryptChar(encryptedMessage.charAt(i), keyValueArray[i]);
       }

       System.out.println(message);
       System.out.println(encryptedMessage);
       System.out.println(decryptedMessage);
	}
  
   public static int[] getKeystream(int messageLength ) {
       /*getKeystream accepts the length of the message you want to encode (n)
        *	turns a predetermined deck into a linked list
        *	runs the cipher algorithm on the deck n times to generate n key values
        *	returns an array of the key values generated. */
	   CircularLinkedList<Integer> deck = new CircularLinkedList<Integer>();
       int[] array = new int[]{1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 3, 6, 9, 12, 15, 18, 21, 24, 27, 2, 5, 8, 11, 14, 17, 20, 23, 26};
       readInDeck(array, deck);
       int[] returnArray = new int[messageLength];
       for (int i = 0; i < messageLength; i++) {
           deck = solitareCipherAlgorithm(deck);   
           int keyValue = deck.get(1);
           if (keyValue != 27 && keyValue != 28){
               returnArray[i] = keyValue;
           } else {
               i--;
           }
       }
       return returnArray;
   }

   public static CircularLinkedList<Integer> solitareCipherAlgorithm(CircularLinkedList<Integer> deck){
       /*solitareCipherAlgorithm accepts a deck
        * 	finds the jokers and swaps them
        * 	performs the triple cut
        * 	moves to the bottom of the deck a number of cards equal to the value of the bottom card 
        * 		after the triple cut has been performed. */
	   int jokerA = findCard(deck, 27);
       swap(deck, jokerA, (jokerA + 1) % 26);
       int jokerB = findCard(deck, 28);
       swap(deck, jokerB, (jokerB + 1) % 26);
       jokerB = findCard(deck, 28);
       swap(deck, jokerB, (jokerB + 1) % 26);
       deck = tripleCut(deck);
       deck = moveToBottom(deck, deck.get(deck.size-1));
       return deck;
   }
	
	public static void readInDeck(int[] inputArray, CircularLinkedList<Integer> deck){
		for (int i = 0; i < inputArray.length; i++) {
			deck.add(inputArray[i] );
		}
	}
	
	public static CircularLinkedList<Integer> moveToBottom(CircularLinkedList<Integer> deck, int valueOfBottomCard){
		int i = 0;
		while(i<valueOfBottomCard) {
			deck.add(deck.remove(0));
			i++;
		}
		return deck;	
	}
	
	public static CircularLinkedList<Integer> tripleCut(CircularLinkedList<Integer> deck) {
		CircularLinkedList<Integer> top = new CircularLinkedList<>();
		CircularLinkedList<Integer> middle = new CircularLinkedList<>();
		CircularLinkedList<Integer> bottom = new CircularLinkedList<>();
		
		while(deck.get(0) != 27 && deck.get(0) != 28) {
			top.add(deck.remove(0));
		}
		middle.add(deck.remove(0));
		while(deck.get(0) != 27 && deck.get(0) != 28) {
			middle.add(deck.remove(0));
		}
		middle.add(deck.remove(0));
		while(deck.size != 0) {
			bottom.add(deck.remove(0));
		}
		while(middle.size != 0) {
			bottom.add(middle.remove(0));
		}
		while(top.size != 0) {
			bottom.add(top.remove(0));
		}
		return bottom;	
	}
		
	public static int findCard(CircularLinkedList<Integer> deck, int cardToFind) {
		for (int i = 0; i < deck.size; i++) {
			if(deck.get(i) == cardToFind) {
				return i;				
			}
		}
		return -1;
	}
	
	public static void swap(CircularLinkedList<Integer> deck, int index1, int index2) {
		int temp = deck.get(index1);
		deck.set(index1, deck.get(index2));
		deck.set(index2, temp);	
	}
	
	public static char encryptChar(char c, int key) {
		char plaintext = (char) (c - 'A');
		char ciphertext =(char) ((plaintext + key) % 26);
	
		return (char) (ciphertext + 'A');
	}
	
	public static char decryptChar(char c, int key) {
		char plaintext = (char) (c - 'A');
		char ciphertext =(char) ((plaintext + (26 - key)) % 26);
	
		return (char) (ciphertext + 'A');
	}
/*		
  Scanner s = new Scanner(System.in);
  System.out.println("Enter phrase to be encrypted.");
  String input = s.nextLine();
  message += input.toLowerCase().strip();
  message = message.replaceAll("\\s", "").replaceAll("\\p{Punct}", "").toUpperCase().strip();
  while (!input.equals("1")){
      message += input.toLowerCase().strip();
      message = message.replaceAll("\\s", "").replaceAll("\\p{Punct}", "");
      System.out.println("If this concludes your message press 1, otherwise enter another message");
      input = s.nextLine();
  }
*/
}
