package arrayListMethods;

import java.util.*;

public class arrayListMethods {

	public static void main(String[] args) {
		List<Integer> inputAllMulitples = new ArrayList<>(Arrays.asList(1, 25, 2, 5, 30, 19, 57, 2, 25));
		System.out.println(allMultiples(inputAllMulitples, 5));
		
		List<String> inputAllSOfSize = new ArrayList<>(Arrays.asList("I", "like", "to", "eat", "eat", "eat",
				"apples", "and", "bananas"));
		System.out.println(allStringsOfSize(inputAllSOfSize, 3));
		
		List<Integer> inputisUnique = new ArrayList<>(Arrays.asList(1, 4, 12, 45, 7, 6, 10));
		System.out.println(isUnique(inputisUnique));

		List<Integer> input1Permutation = new ArrayList<>(Arrays.asList(2, 1, 4));
		List<Integer> input2Permutation = new ArrayList<>(Arrays.asList(1, 2, 4));
		System.out.println(isPermutaion(input1Permutation, input2Permutation));
		
		List<Integer> inputremoveAllI = new ArrayList<>(Arrays.asList(1, 4, 5, 6, 5, 5, 2));
		removeAllInstances(inputremoveAllI, 5);
		System.out.println(inputremoveAllI);

		String inputListOfWords = "Hello, World! this% $%is   $ %   $     *   a t$est";
		System.out.println(stringToListOfWords(inputListOfWords));



	}

	public static List<Integer> allMultiples(List <Integer> list, int multiple){
		List<Integer> returnList = new ArrayList<Integer>();
		for(int i=0; i< list.size(); i++) {
			if((list.get(i)) % multiple == 0 ) {
				returnList.add(list.get(i));
			}
		}
		return returnList;
	}

	public static List<String> allStringsOfSize(List<String> list, int length){
		List<String> returnList = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).length() == length) {
				returnList.add(list.get(i));
			}
		}
		return returnList;
	}

	public static <E> boolean isUnique(List<E> list) {		
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < list.size(); j++) {
				if((list.get(i) == list.get(j)) && i != j) {
					return false;
				}
			}
		}
		return true;
	}

	public static <E> boolean isPermutaion(List<E> list1, List<E> list2) {		
		if(list1.size() != list2.size()) {
			return false;
		}
		for(E item: list1) {
			int countA = 0;
			int countB = 0;
			for(E a: list1) {
				if(item.equals(a)) {
					countA++;					
				}
			}
			for(E b: list2) {
				if(item.equals(b)) {
					countB++;					
				}
			}
			if(countA != countB) {
				return false;				
			}
		}
		return true;
	}

	public static <E> void removeAllInstances(List<E> list, E item) {
		  /*will only work for a single item as it stands, if we wanted to 
			remove more than one thing we would have to make an array of the 
			items to remove and pass it to remove all as a collection*/
			list.removeAll(Collections.singleton(item));
		}

	public static List<String> stringToListOfWords(String input){
		input = input.replaceAll("\\p{Punct}", "");
		Scanner s = new Scanner(input);
		List<String> returnList = new ArrayList<String>();
		String word  = "";
		while(s.hasNext()){
			word  = s.next();			
			returnList.add(word);
		}
		return returnList;
	}
}	
