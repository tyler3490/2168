package indexTree;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

// Your class. Notice how it has no generics.
// This is because we use generics when we have no idea what kind of data we are getting
// Here we know we are getting two pieces of data:  a string and a line number
public class IndexTree {

	// This is your root 
	// again, your root does not use generics because you know your nodes
	// hold strings, an int, and a list of integers
	private IndexNode root;
	
	// Make your constructor
	// It doesn't need to do anything
	public int size = 0;
	public void IndexTree() {
		
	}
	
	
	// complete the methods below
	
	// this is your wrapper method
	// it takes in two pieces of data rather than one
	// call your recursive add method
	public void add(String word, int lineNumber){
		this.root = add(root, word, lineNumber);
		size++;
	}
	
	
	
	// your recursive method for add
	// Think about how this is slightly different the the regular add method
	// When you add the word to the index, if it already exists, 
	// you want to  add it to the IndexNode that already exists
	// otherwise make a new indexNode
	private IndexNode add(IndexNode root, String word, int lineNumber){
		if(root == null) {
			return new IndexNode(word, lineNumber);
		}
		int result = word.compareTo(root.word);
		if(result == 0) {
			root.occurences++;
			root.list.add(lineNumber);
			return root;
		}
		else if(result < 0) {
//			word is "less than" the current node so go to the left
			root.left = add(root.left, word, lineNumber);
			return root;
		}
		else {
//			word is "greater than" the current node so go to the right
			root.right = add(root.right, word, lineNumber);
			return root;
		}
	}
	
	
	
	
	// returns true if the word is in the index
//	wrapper method just like earlier 
//	wrapper used to prevent user from monkeying around with the real class, also makes it a bit easier to call since it just takes one parameter i.e. keeps things local 
	public boolean contains(String word) {
		return contains(this.root, word);
	}
	
	private boolean contains(IndexNode root, String word){
		if(root == null) {
			return false;
		}
		int compare = word.compareTo(root.word);
		if(compare == 0) {
			return true;
		}else if(compare < 0) {
			return contains(root.left, word);
		}else {
			return contains(root.right, word);
		}
	}
	
	// call your recursive method
	// use book as guide
	public void delete(String word){
		this.root = this.delete(this.root, word);
		size--;
	}
	
	// your recursive case
	// remove the word and all the entries for the word
	// This should be no different than the regular technique.
	private IndexNode delete(IndexNode root, String word){
		if (root == null) {
			return null;
		}
		int compare = word.compareTo(root.word);
		if (compare < 0) {
			root.left = delete(root.left, word);
			return root;
		}else if (compare > 0) {
			root.right = delete(root.right, word);
			return root;
		}else {
			if (root.left == null && root.right == null) {
				return null;
			}else if (root.left == null && root.right != null) {
				return root.right;
			}else if (root.left != null && root.right == null) {
				return root.left;
			}else {
//				this node has 2 children so we need to ge either left and all the way right or right and all the way left 
//				ill do left and all the way right 
				IndexNode cur = root.left;
				while (cur.right != null) {
					cur = cur.right;
				}
//				transfer all the data once we get to the end node ???????? we will try and see if this works 
				root.word = cur.word;
				root.list = cur.list;
				root.occurences = cur.occurences;
//				reassign the main root and then call remove on the duplicate 
				root.left = delete(root.left, root.word);
				return root;
			}
		}
	}
	
	
	// prints all the words in the index in inorder order
//		visit the left, root, right 
	// To successfully print it out
	// this should print out each word followed by the number of occurrences and the list of all occurrences
	// each word and its data gets its own line
//	word: test, occurrences: 34, line numbers: 1, 2, 3, 4, 5
	
	public StringBuilder printIndex() {
		StringBuilder sb = new StringBuilder();
		inOrderTraversal(root, sb);
		return sb;
	}
	
	private void inOrderTraversal(IndexNode root, StringBuilder sb) {
		
		if (root == null) {
			sb.append("");
			return;
			
		}else {
			inOrderTraversal(root.left, sb);
			sb.append(root.toString() + "\n");
			inOrderTraversal(root.right, sb);
		}	
	}

	public static void main(String[] args){
		IndexTree index = new IndexTree();
		String fileName = "pg100.txt";
		try {
			Scanner scanner = new Scanner(new File(fileName));
			int i = 1;
			while(scanner.hasNextLine()){
				String line = scanner.nextLine();
				String[] words = line.split("\\s+");
				if (line.contentEquals("")) {
					continue;
				}else {
					for(String word : words){
						word = word.replaceAll("\\s", "");
						word = word.replaceAll("\\p{Punct}", "");
						if (word.contentEquals("")) {
							continue;
						}else {
							index.add(word, i);							
						}
					}
				}
				i++;
			}
			
			scanner.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	
		
//		index.add("a", 1);
//		index.add("f", 9);
//		index.add("s", 6);
//		index.add("2", 4);
//		index.add("d", 3);
//		index.add("d", 87);
//		index.add("d", 4);
//		System.out.print(index.printIndex());			
//		index.delete("2");
//		index.delete("d");
//		System.out.println();
		System.out.print(index.printIndex());

	}
}
