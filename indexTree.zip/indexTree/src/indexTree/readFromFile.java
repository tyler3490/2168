package indexTree;
import java.io.*;
import java.util.*;
public class readFromFile {
	public static void main(String [] args) {
		String fileName = "pg100.txt";
		try {
			Scanner scanner = new Scanner(new File(fileName));
			int i = 1;
			while(scanner.hasNextLine()){
				String line = scanner.nextLine();
				String[] words = line.split("\\s+");
				if (line.contentEquals("")) {
					continue;
				}else {
					for(String word : words){
						word = word.replaceAll("\\s", "");
						word = word.replaceAll("\\p{Punct}", "");
						if (word.contentEquals("")) {
							continue;
						}else {
							System.out.println(word);
							i++;
						}
					}
				}
					
					
				}
			
			scanner.close();
			
			System.out.println(i);
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
	}
}


