public class Rabbit extends Animal {
    private int direction = 1;

    public Rabbit(Model model, int row, int column) {
        super(model, row, column);
    }
    /*the idea is to stay out of the foxes line of sight, moving counter clockwise is better because when the fox loses track of the rabbit 
    it first looks in a clockwise direction for a legal move thus most of the time a move counter clockwise AWAY from the fox
    will put the rabbit outside of its line of sight*/
    int decideMove() {
        //first look in every direction
        for (int i = Model.MIN_DIRECTION; i <= Model.MAX_DIRECTION; i++)
            if (look(i) == Model.FOX) {
                //if you see a fox turn 3 spaces counter clockwise
                direction = Model.turn(i, -3);
                //then check to see if you can move in that direction (make sure its not a bush or the edge)
                while (!canMove(direction)){
                	//if you cannot go in that direction keep turning one space counter clockwise until you can make a legal move
                    direction = Model.turn(direction, -1);
                }
              return direction;	
            }
        //the default move is to just stay still, there is no point in moving if the fox doesnt see you 
        return Model.STAY;
    }
}